import os
import requests
import json
from dotenv import load_dotenv
from datetime import datetime

# .env 파일 로드
load_dotenv()

def get_school_meal(school_code, api_key):
   meal_url = "https://open.neis.go.kr/hub/mealServiceDietInfo"
   today = datetime.now().strftime("%Y%m%d")  # 현재 날짜
   
   meal_params = {
       'KEY': api_key,
       'Type': 'json',
       'pIndex': '1',
       'pSize': '100',
       'ATPT_OFCDC_SC_CODE': 'T10',  # 제주도교육청 코드
       'SD_SCHUL_CODE': school_code,
       'MLSV_YMD': today
   }
   
   try:
       meal_response = requests.get(meal_url, params=meal_params)
       meal_data = meal_response.json()
       
       if 'mealServiceDietInfo' in meal_data:
           meal_info = meal_data['mealServiceDietInfo'][1]['row'][0]
           lunch_menu = meal_info['DDISH_NM']
           # 기본 출력용 급식 메뉴 (알레르기 정보 제거)
           simple_menu = ' '.join([item.split("(")[0] for item in lunch_menu.split("<br/>")])
           # 상세 정보용 급식 메뉴
           detailed_menu = lunch_menu.split("<br/>")
           return simple_menu, detailed_menu
       else:
           return "급식 정보 없음", []
   except:
       return "급식 정보 없음", []

# 학교 정보 가져오기
url = "https://open.neis.go.kr/hub/schoolInfo"
api_key = os.getenv('NEIS_API_KEY')

params = {
   'KEY': api_key,
   'Type': 'json',
   'pIndex': '1',
   'pSize': '1000',
   'ATPT_OFCDC_SC_CODE': 'T10',  # 제주도교육청 코드
   'SCHUL_KND_SC_NM': '고등학교'  # 고등학교만 필터링
}

response = requests.get(url, params=params)

if response.status_code == 200:
   try:
       data = response.json()
       schools = data['schoolInfo'][1]['row']
       today = datetime.now().strftime("%Y년 %m월 %d일")
       
       # 콘솔 출력용
       
       
       # JSON 저장용 데이터
       school_meals = []
       
       for i, school in enumerate(schools, 1):
           simple_menu, detailed_menu = get_school_meal(school['SD_SCHUL_CODE'], api_key)
           
           # 콘솔 출력
           print(f"{i:2d}\t{school['SD_SCHUL_CODE']}\t\t\t{school['SCHUL_NM']:12}    {simple_menu}")
           
           # JSON 데이터 구조
           school_data = {
               "school_code": school['SD_SCHUL_CODE'],
               "school_name": school['SCHUL_NM'],
               "lunch_menu": simple_menu,
               "lunch_menu_details": detailed_menu
           }
           school_meals.append(school_data)
       
       print(f"\n총 {len(schools)}개 고등학교")
       
       # JSON 파일로 저장
       filename = f"school_meals_{datetime.now().strftime('%Y%m%d')}.json"
       with open(filename, 'w', encoding='utf-8') as f:
           json.dump(school_meals, f, ensure_ascii=False, indent=4)
           
       print(f"\n급식 정보가 {filename}에 저장되었습니다.")
           
   except KeyError:
       print("학교 데이터가 없거나 형식이 올바르지 않습니다.")
   except json.JSONDecodeError:
       print("JSON 파싱 오류가 발생했습니다.")
else:
   print(f"API 요청 실패: {response.status_code}")