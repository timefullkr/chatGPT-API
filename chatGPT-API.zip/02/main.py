import os
from openai import OpenAI
from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import uvicorn  # 추가
from duckduckgo_search import DDGS

# pip install fastapi uvicorn jinja2 python-multipart

load_dotenv()
client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

app = FastAPI()
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")

class ChatMessage(BaseModel):
    message: str

def search_web(query, num_results=20):
    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=num_results))
            return [f"제목: {r['title']}\n내용: {r['body']}\n출처: {r['href']}" for r in results]
    except Exception as e:
        return [f"검색 중 오류 발생: {str(e)}"]
@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("chat.html", {"request": request})

# 대화 기록을 저장할 리스트 추가
chat_history = []

@app.post("/chat")
async def chat_endpoint(message: ChatMessage):
    try:
        # 웹 검색 수행
        search_results = search_web(message.message)
        
        # 대화 기록에 사용자 메시지 추가
        chat_history.append({"role": "user", "content": message.message})
        
        # GPT에 검색 결과와 함께 프롬프트 전송
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": f"다음은 질문과 관련된 웹 검색 결과입니다:\n{search_results}"},
                *chat_history  # 대화 기록 추가
            ]
        )
        
        # 대화 기록에 GPT 응답 추가
        chat_history.append({"role": "assistant", "content": response.choices[0].message.content})
        
        return {"response": response.choices[0].message.content}
    except Exception as e:
        return {"error": f"오류가 발생했습니다: {str(e)}"}

# 파일을 직접 실행할 때만 서버를 시작하는 코드 추가
if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)