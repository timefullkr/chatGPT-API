import os
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import requests
import json
from dotenv import load_dotenv
from datetime import datetime, timedelta
from openai import OpenAI
from pathlib import Path

# Load environment variables
load_dotenv()

# Initialize FastAPI app
app = FastAPI()

# CORS 설정
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Initialize OpenAI client
client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

# Constants
NEIS_API_KEY = os.getenv('NEIS_API_KEY')
DATA_DIR = Path("data")
if not DATA_DIR.exists():
    DATA_DIR.mkdir()

def get_menu_review(menu):
    """Generate a review for the given menu using OpenAI API"""
    if menu == "급식 정보 없음":
        return "급식 정보가 없습니다.", 0
        
    try:
        prompt = f"""
다음 학교 급식 메뉴에 대해 간단히 평가해주세요:
{menu}

다음 형식으로 한 문장씩만 응답해주세요:
1. 영양적 특징 한 문장
2. 추천 이유나 개선점 한 문장
3. 1-5점 사이의 점수 (#RATE:숫자)

예시)
- 탄수화물, 단백질, 비타민이 균형잡힌 영양가 있는 식단입니다.
- 채소의 비중을 조금 더 높이면 좋을 것 같습니다.
#RATE:4
"""
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}]
        )
        
        review = response.choices[0].message.content
        rating_line = [line for line in review.split('\n') if line.startswith('#RATE:')]
        
        if rating_line:
            try:
                rating = float(rating_line[0].split(':')[1])
                review = '\n'.join(line for line in review.split('\n') 
                                 if not line.startswith('#RATE:'))
            except:
                rating = 0
        else:
            rating = 0
        
        return review.strip(), rating
    except Exception as e:
        return f"리뷰 생성 중 오류 발생: {str(e)}", 0

def get_school_meal(school_code, date):
    """Fetch meal data for a specific school and date"""
    meal_url = "https://open.neis.go.kr/hub/mealServiceDietInfo"
    
    meal_params = {
        'KEY': NEIS_API_KEY,
        'Type': 'json',
        'pIndex': '1',
        'pSize': '100',
        'ATPT_OFCDC_SC_CODE': 'T10',
        'SD_SCHUL_CODE': school_code,
        'MLSV_YMD': date.strftime("%Y%m%d")
    }
    
    try:
        meal_response = requests.get(meal_url, params=meal_params)
        meal_data = meal_response.json()
        
        if 'mealServiceDietInfo' in meal_data:
            meal_info = meal_data['mealServiceDietInfo'][1]['row'][0]
            lunch_menu = meal_info['DDISH_NM']
            simple_menu = ','.join([item.split("(")[0].strip() 
                                  for item in lunch_menu.split("<br/>")])
            detailed_menu = lunch_menu.split("<br/>")
            return simple_menu, detailed_menu
        else:
            return "급식 정보 없음", []
    except:
        return "급식 정보 없음", []

def get_reactions(date, school_code):
    """Get reactions for a specific school and date"""
    reactions_file = DATA_DIR / f"reactions_{date.strftime('%Y%m%d')}.json"
    
    if reactions_file.exists():
        with open(reactions_file, 'r', encoding='utf-8') as f:
            reactions_data = json.load(f)
            return reactions_data.get(school_code, {"likes": 0, "dislikes": 0})
    
    return {"likes": 0, "dislikes": 0}

def get_school_meals_data(target_date):
    """Get or create meal data for all schools on a specific date"""
    filename = DATA_DIR / f"school_meals_review_{target_date.strftime('%Y%m%d')}.json"
    
    # Return existing data if available
    if filename.exists():
        with open(filename, 'r', encoding='utf-8') as f:
            meals_data = json.load(f)
            # Update reactions data
            for meal in meals_data:
                meal['reactions'] = get_reactions(target_date, meal['school_code'])
            return meals_data
    
    # Fetch new data if not exists
    url = "https://open.neis.go.kr/hub/schoolInfo"
    
    params = {
        'KEY': NEIS_API_KEY,
        'Type': 'json',
        'pIndex': '1',
        'pSize': '1000',
        'ATPT_OFCDC_SC_CODE': 'T10',
        'SCHUL_KND_SC_NM': '고등학교'
    }
    
    response = requests.get(url, params=params)
    school_meals = []
    
    if response.status_code == 200:
        try:
            data = response.json()
            schools = data['schoolInfo'][1]['row']
            
            for school in schools:
                simple_menu, detailed_menu = get_school_meal(
                    school['SD_SCHUL_CODE'],
                    target_date
                )
                
                menu_review, rating = get_menu_review(simple_menu)
                stars = '★' * int(rating) + '☆' * (5 - int(rating)) if simple_menu != "급식 정보 없음" else ""
                
                reactions = get_reactions(target_date, school['SD_SCHUL_CODE'])
                
                school_data = {
                    "school_code": school['SD_SCHUL_CODE'],
                    "school_name": school['SCHUL_NM'],
                    "lunch_menu": simple_menu,
                    "lunch_menu_details": detailed_menu,
                    "menu_review": menu_review,
                    "rating": rating,
                    "stars": stars,
                    "reactions": reactions
                }
                school_meals.append(school_data)
            
            # Save data to file
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(school_meals, f, ensure_ascii=False, indent=4)
                
            return school_meals
            
        except Exception as e:
            raise Exception(f"Error processing school data: {str(e)}")
    
    raise Exception("Failed to fetch school data")

# FastAPI Routes

@app.get("/")
async def home():
    """Serve the main HTML page"""
    return FileResponse("static/index.html")

@app.get("/api/dates")
async def get_dates():
    """Get date range for the meal data"""
    today = datetime.now()
    dates = [
        (today + timedelta(days=i)).strftime("%Y-%m-%d")
        for i in range(-3, 4)
    ]
    return {
        "dates": dates,
        "selected_date": today.strftime("%Y-%m-%d")
    }

@app.get("/api/meals/{date}")
async def get_meals(date: str):
    """Get meal data for a specific date"""
    try:
        target_date = datetime.strptime(date, "%Y-%m-%d")
        return get_school_meals_data(target_date)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/reaction/{date}/{school_code}/{reaction_type}")
async def update_reaction(date: str, school_code: str, reaction_type: str):
    """Update reaction (like/dislike) for a school's meal"""
    if reaction_type not in ["like", "dislike"]:
        raise HTTPException(status_code=400, detail="Invalid reaction type")
        
    target_date = datetime.strptime(date, "%Y-%m-%d")
    reactions_file = DATA_DIR / f"reactions_{target_date.strftime('%Y%m%d')}.json"
    
    try:
        if reactions_file.exists():
            with open(reactions_file, 'r', encoding='utf-8') as f:
                reactions_data = json.load(f)
        else:
            reactions_data = {}
        
        if school_code not in reactions_data:
            reactions_data[school_code] = {"likes": 0, "dislikes": 0}
        
        reactions_data[school_code][f"{reaction_type}s"] += 1
        
        with open(reactions_file, 'w', encoding='utf-8') as f:
            json.dump(reactions_data, f, ensure_ascii=False, indent=4)
        
        return reactions_data[school_code]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)