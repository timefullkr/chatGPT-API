import os
import requests
import json
from dotenv import load_dotenv
from datetime import datetime
from openai import OpenAI

# .env 파일 로드
load_dotenv()

# OpenAI 클라이언트 초기화
client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

def get_menu_review(menu):
   if menu == "급식 정보 없음":
       return "급식 정보가 없습니다.", "-"
       
   try:
       prompt = f"""
다음 학교 급식 메뉴에 대해 간단히 평가해주세요:
{menu}

다음 형식으로 한 문장씩만 응답해주세요:
1. 영양적 특징 한 문장
2. 추천 이유나 개선점 한 문장
3. 1-5점 사이의 점수 (#RATE:숫자)

예시)
- 탄수화물, 단백질, 비타민이 균형잡힌 영양가 있는 식단입니다.
- 채소의 비중을 조금 더 높이면 좋을 것 같습니다.
#RATE:4
"""
       response = client.chat.completions.create(
           model="gpt-4",
           messages=[{"role": "user", "content": prompt}]
       )
       
       review = response.choices[0].message.content
       
       # #RATE: 태그로부터 별점 추출
       rating_line = [line for line in review.split('\n') if line.startswith('#RATE:')]
       if rating_line:
           try:
               rating = float(rating_line[0].split(':')[1])
               # 리뷰에서 #RATE 줄 제거
               review = '\n'.join(line for line in review.split('\n') if not line.startswith('#RATE:'))
           except:
               rating = 0
       else:
           rating = 0
       
       return review.strip(), rating
   except Exception as e:
       return f"리뷰 생성 중 오류 발생: {str(e)}", 0

def get_school_meal(school_code, api_key):
   meal_url = "https://open.neis.go.kr/hub/mealServiceDietInfo"
   today = datetime.now().strftime("%Y%m%d")
   
   meal_params = {
       'KEY': api_key,
       'Type': 'json',
       'pIndex': '1',
       'pSize': '100',
       'ATPT_OFCDC_SC_CODE': 'T10',
       'SD_SCHUL_CODE': school_code,
       'MLSV_YMD': today
   }
   
   try:
       meal_response = requests.get(meal_url, params=meal_params)
       meal_data = meal_response.json()
       
       if 'mealServiceDietInfo' in meal_data:
           meal_info = meal_data['mealServiceDietInfo'][1]['row'][0]
           lunch_menu = meal_info['DDISH_NM']
           simple_menu = ','.join([item.split("(")[0].strip() for item in lunch_menu.split("<br/>")])
           detailed_menu = lunch_menu.split("<br/>")
           return simple_menu, detailed_menu
       else:
           return "급식 정보 없음", []
   except:
       return "급식 정보 없음", []

# 학교 정보 가져오기
url = "https://open.neis.go.kr/hub/schoolInfo"
api_key = os.getenv('NEIS_API_KEY')

params = {
   'KEY': api_key,
   'Type': 'json',
   'pIndex': '1',
   'pSize': '1000',
   'ATPT_OFCDC_SC_CODE': 'T10',
   'SCHUL_KND_SC_NM': '고등학교'
}

response = requests.get(url, params=params)

if response.status_code == 200:
   try:
       data = response.json()
       schools = data['schoolInfo'][1]['row']
       today = datetime.now().strftime("%Y년 %m월 %d일")
       
       print(f"\n[ 제주도 고등학교 급식 정보 및 분석 - {today} ]")
       print("\n연번  학교코드    학교명           점심 식단")
       print("-" * 100)
       
       school_meals = []
       
       for i, school in enumerate(schools, 1):
           simple_menu, detailed_menu = get_school_meal(school['SD_SCHUL_CODE'], api_key)
           menu_review, rating = get_menu_review(simple_menu)
           
           # 별점을 ★로 표시 (빈 별은 ☆)
           
           
           print(f"\n{i:2d}    {school['SD_SCHUL_CODE']}    {school['SCHUL_NM']:12}")
           print(f"메뉴: {simple_menu}")
           if simple_menu != "급식 정보 없음":
            stars = '★' * int(rating) + '☆' * (5 - int(rating))
            print(f"평가: {stars} ({rating}점)")
            print(f"리뷰: {menu_review}")
           else:
            print("평가: 급식 정보 없음")
            print("-" * 100)
           
           school_data = {
               "school_code": school['SD_SCHUL_CODE'],
               "school_name": school['SCHUL_NM'],
               "lunch_menu": simple_menu,
               "lunch_menu_details": detailed_menu,
               "menu_review": menu_review,
               "rating": rating,
               "stars": stars if simple_menu != "급식 정보 없음" else ""
           }
           school_meals.append(school_data)
       
       print(f"\n총 {len(schools)}개 고등학교")
       
       # JSON 파일로 저장
       filename = f"school_meals_review_{datetime.now().strftime('%Y%m%d')}.json"
       with open(filename, 'w', encoding='utf-8') as f:
           json.dump(school_meals, f, ensure_ascii=False, indent=4)
           
       print(f"\n급식 정보와 분석이 {filename}에 저장되었습니다.")
           
   except KeyError:
       print("학교 데이터가 없거나 형식이 올바르지 않습니다.")
   except json.JSONDecodeError:
       print("JSON 파싱 오류가 발생했습니다.")
else:
   print(f"API 요청 실패: {response.status_code}")