import os
from openai import OpenAI
from dotenv import load_dotenv
from duckduckgo_search import DDGS
import time

load_dotenv()
client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))


def search_web(query, num_results=20):
    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=num_results))
            return [f"제목: {r['title']}\n내용: {r['body']}\n출처: {r['href']}" for r in results]
    except Exception as e:
        return [f"검색 중 오류 발생: {str(e)}"]


def chat_with_gpt(message, conversation_history=[]):
    try:
        # 웹 검색 수행
        search_results = search_web(message)
        search_context = "\n\n".join(search_results)
        
        # 시스템 메시지와 검색 결과를 포함한 프롬프트 구성
        system_message = {
            "role": "system",
            "content": f"다음은 질문과 관련된 최신 웹 검색 결과입니다:\n\n{search_context}\n\n이 정보를 참고하여 답변해주세요. 검색 결과를 인용할 때는 출처를 명시해주세요."
        }
        
        # 대화 기록을 포함한 메시지 구성
        messages = [system_message] + conversation_history + [{"role": "user", "content": message}]
        
        # API 요청
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=messages
        )
        
        # 응답 저장
        assistant_message = response.choices[0].message.content
        conversation_history.append({"role": "user", "content": message})
        conversation_history.append({"role": "assistant", "content": assistant_message})
        
        return assistant_message, conversation_history
    
    except Exception as e:
        return f"오류가 발생했습니다: {str(e)}", conversation_history


if __name__ == "__main__":
    conversation_history = []

    print("ChatGPT와 대화를 시작합니다.")
    
    while True:
        user_input = input("\n질문을 입력하세요: ").strip()
        
        if user_input.lower() == '':
            break
        
        print("\nGPT가 응답하는 중...", end='', flush=True)
        response, conversation_history = chat_with_gpt(user_input, conversation_history)
        print("\r" + " " * 20 + "\r")  # 로딩 메시지 지우기
        print("GPT 응답:", response, "\n")