import os
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
import requests
import sqlite3
from dotenv import load_dotenv
from datetime import datetime, timedelta
from openai import OpenAI
from pathlib import Path

# 기본 설정
BASE_DIR = Path(__file__).resolve().parent
(BASE_DIR / 'static').mkdir(exist_ok=True)
(BASE_DIR / 'data').mkdir(exist_ok=True)

# 환경 변수 로드
load_dotenv()

# FastAPI 앱 초기화
app = FastAPI()
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

# OpenAI 클라이언트 초기화
client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

# 데이터베이스 설정
DB_PATH = str(BASE_DIR / "data" / "school_meals.db")

def init_db():
    """데이터베이스 초기화"""
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute('''
            CREATE TABLE IF NOT EXISTS meals (
                date TEXT,
                school_code TEXT,
                school_name TEXT,
                lunch_menu TEXT,
                PRIMARY KEY (date, school_code)
            )
        ''')
        c.execute('''
            CREATE TABLE IF NOT EXISTS reviews (
                date TEXT,
                school_code TEXT,
                review_text TEXT,
                rating REAL,
                PRIMARY KEY (date, school_code)
            )
        ''')
        c.execute('''
            CREATE TABLE IF NOT EXISTS reactions (
                date TEXT,
                school_code TEXT,
                likes INTEGER DEFAULT 0,
                dislikes INTEGER DEFAULT 0,
                PRIMARY KEY (date, school_code)
            )
        ''')
        c.execute('''
            CREATE TABLE IF NOT EXISTS visits (
                date TEXT PRIMARY KEY,
                count INTEGER DEFAULT 0
            )
        ''')

init_db()

async def get_menu_review(menu: str):
    """메뉴 리뷰 생성"""
    if not menu or menu == "급식 정보 없음":
        return "급식 정보가 없습니다.", 0
        
    try:
        prompt = f"""
다음 학교 급식 메뉴에 대해 영양학적 관점에서 분석하고 평가해주세요:

메뉴: {menu}

다음 형식으로 응답해주세요:
1. 영양적 특징과 균형에 대한 평가 (한 문장)
2. 개선점이나 장점 (한 문장)
3. 점수는 1-5 사이의 숫자로 (#RATE:숫자)

응답 예시:
이 메뉴는 영양가가 높고 균형이 잘 잡혀있습니다.
단백질 함량을 조금 더 높이면 좋을 것 같습니다.
#RATE:4
"""
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=250
        )
        
        review = response.choices[0].message.content.strip()
        lines = review.split('\n')
        rating = 3
        review_lines = []
        
        for line in lines:
            if line.startswith('#RATE:'):
                try:
                    rating = float(line.replace('#RATE:', '').strip())
                    rating = min(max(rating, 1), 5)
                except ValueError:
                    pass
            elif line.strip():
                review_lines.append(line.strip())
        
        review = '\n'.join(review_lines)
        if not review:
            return "메뉴 분석 결과를 생성하지 못했습니다.", 3
            
        return review, rating
        
    except Exception as e:
        print(f"Review error: {str(e)}")
        return "메뉴 분석 중 오류가 발생했습니다.", 3

def increment_visits(date_str):
    """방문자 수 증가"""
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute('INSERT INTO visits (date, count) VALUES (?, 1) ON CONFLICT(date) DO UPDATE SET count = count + 1', (date_str,))
        conn.commit()
        c.execute('SELECT count FROM visits WHERE date = ?', (date_str,))
        return c.fetchone()[0]

def get_school_meals(date_str):
    """급식 정보 조회"""
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute('''
            SELECT school_code, school_name, lunch_menu
            FROM meals
            WHERE date = ? AND lunch_menu != '급식 정보 없음'
        ''', (date_str,))
        return [{"school_code": row[0], "school_name": row[1], "lunch_menu": row[2]} for row in c.fetchall()]


def get_school_review(date_str, school_code):
    """리뷰 정보 조회"""
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute('''
            SELECT r.review_text, r.rating, 
                   COALESCE(rc.likes, 0) as likes, 
                   COALESCE(rc.dislikes, 0) as dislikes
            FROM reviews r
            LEFT JOIN reactions rc ON r.date = rc.date AND r.school_code = rc.school_code
            WHERE r.date = ? AND r.school_code = ?
        ''', (date_str, school_code))
        
        row = c.fetchone()
        if row:
            rating = float(row[1])  # 확실한 float 변환
            full_stars = int(rating)  # 정수부분 (꽉 찬 별)
            has_half = (rating - full_stars) >= 0.5  # 소수점이 0.5 이상이면 반별
            empty_stars = 5 - full_stars - (1 if has_half else 0)  # 빈 별 개수
            
            stars = "★" * full_stars
            if has_half:
                stars += "☆"
            stars += "☆" * empty_stars
            
            return {
                "review": row[0],
                "rating": rating,
                "stars": stars,
                "reactions": {"likes": row[2], "dislikes": row[3]}
            }
        return None
    
async def fetch_school_meals(target_date):
    """NEIS API에서 급식 정보 조회 (6개 학교만, 가나다순)"""
    api_key = os.getenv('NEIS_API_KEY')
    date_str = target_date.strftime("%Y%m%d")
    
    # 학교 목록 조회
    school_response = requests.get(
        "https://open.neis.go.kr/hub/schoolInfo",
        params={
            'KEY': api_key,
            'Type': 'json',
            'pIndex': '1',
            'pSize': '1000',
            'ATPT_OFCDC_SC_CODE': 'T10',
            'SCHUL_KND_SC_NM': '고등학교'
        }
    )
    
    if 'schoolInfo' in school_response.json():
        # 모든 학교 정보를 가져와서 필터링 및 정렬
        schools = school_response.json()['schoolInfo'][1]['row']
        
        # 학교명에서 "제주" 제거하고 가나다순으로 정렬
        schools = sorted(
            schools,
            key=lambda x: x['SCHUL_NM'].replace('제주', '')
        )
        
        # 상위 6개 학교만 선택
        selected_schools = schools
        
        for school in selected_schools:
            # "제주" 제거한 학교명 사용
            school_name = school['SCHUL_NM'].replace('제주', '')
            
            # 급식 정보 조회
            meal_response = requests.get(
                "https://open.neis.go.kr/hub/mealServiceDietInfo",
                params={
                    'KEY': api_key,
                    'Type': 'json',
                    'pIndex': '1',
                    'pSize': '100',
                    'ATPT_OFCDC_SC_CODE': 'T10',
                    'SD_SCHUL_CODE': school['SD_SCHUL_CODE'],
                    'MLSV_YMD': date_str
                }
            )
            
            try:
                meal_data = meal_response.json()
                if 'mealServiceDietInfo' in meal_data:
                    menu = meal_data['mealServiceDietInfo'][1]['row'][0]['DDISH_NM']
                    simple_menu = ','.join([item.split("(")[0].strip() for item in menu.split("<br/>")])
                else:
                    simple_menu = "급식 정보 없음"
                
                # 급식 정보 저장 (수정된 학교명으로)
                with sqlite3.connect(DB_PATH) as conn:
                    conn.execute(
                        'INSERT OR REPLACE INTO meals (date, school_code, school_name, lunch_menu) VALUES (?, ?, ?, ?)',
                        (date_str, school['SD_SCHUL_CODE'], school_name, simple_menu)
                    )
            except Exception as e:
                print(f"Error fetching meal for {school_name}: {str(e)}")

# API 라우트
@app.get("/")
async def home():
    """메인 페이지"""
    today = datetime.now().strftime("%Y%m%d")
    increment_visits(today)
    return FileResponse(str(BASE_DIR / "static" / "index.html"))

@app.get("/api/visits/today")
async def get_today_visits():
    """오늘의 방문자 수"""
    today = datetime.now().strftime("%Y%m%d")
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute('SELECT count FROM visits WHERE date = ?', (today,))
        result = c.fetchone()
        return {"count": result[0] if result else 0}

@app.get("/api/meals/{date}")
async def get_meals(date: str):
    """급식 정보 조회"""
    try:
        target_date = datetime.strptime(date, "%Y-%m-%d")
        date_str = target_date.strftime("%Y%m%d")
        
        meals = get_school_meals(date_str)
        if not meals:
            await fetch_school_meals(target_date)
            meals = get_school_meals(date_str)
        return meals
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/review/{date}/{school_code}")
async def get_review(date: str, school_code: str):
    """리뷰 조회 및 생성"""
    try:
        target_date = datetime.strptime(date, "%Y-%m-%d")
        date_str = target_date.strftime("%Y%m%d")
        
        review = get_school_review(date_str, school_code)
        if not review:
            meals = get_school_meals(date_str)
            meal = next((m for m in meals if m['school_code'] == school_code), None)
            
            if meal and meal.get('lunch_menu'):
                review_text, rating = await get_menu_review(meal['lunch_menu'])
                with sqlite3.connect(DB_PATH) as conn:
                    conn.execute(
                        'INSERT OR REPLACE INTO reviews (date, school_code, review_text, rating) VALUES (?, ?, ?, ?)',
                        (date_str, school_code, review_text, rating)
                    )
                
                review = {
                    "review": review_text,
                    "rating": rating,
                    "stars": "★" * int(rating) + "☆" * (5 - int(rating)),
                    "reactions": {"likes": 0, "dislikes": 0}
                }
        return review
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/reaction/{date}/{school_code}/{reaction_type}")
async def handle_reaction(date: str, school_code: str, reaction_type: str):
    """반응 처리"""
    try:
        if reaction_type not in ["like", "dislike"]:
            raise HTTPException(status_code=400, detail="Invalid reaction type")
        
        target_date = datetime.strptime(date, "%Y-%m-%d")
        date_str = target_date.strftime("%Y%m%d")
        
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute(
                'INSERT OR IGNORE INTO reactions (date, school_code, likes, dislikes) VALUES (?, ?, 0, 0)',
                (date_str, school_code)
            )
            
            if reaction_type == 'like':
                c.execute(
                    'UPDATE reactions SET likes = CASE WHEN likes = 0 THEN 1 ELSE 0 END WHERE date = ? AND school_code = ?',
                    (date_str, school_code)
                )
            else:
                c.execute(
                    'UPDATE reactions SET dislikes = CASE WHEN dislikes = 0 THEN 1 ELSE 0 END WHERE date = ? AND school_code = ?',
                    (date_str, school_code)
                )
            
            c.execute('SELECT likes, dislikes FROM reactions WHERE date = ? AND school_code = ?', (date_str, school_code))
            likes, dislikes = c.fetchone()
            return {"likes": likes, "dislikes": dislikes}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
@app.get("/api/visits/total")
async def get_total_visits():
    """총 방문자 수 조회"""
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        # 모든 날짜의 방문자 수 합계 조회
        c.execute('SELECT COALESCE(SUM(count), 0) FROM visits')
        result = c.fetchone()
        return {"count": result[0] if result else 0}

@app.get("/api/dates")
async def get_dates():
    """날짜 범위 조회"""
    today = datetime.now()
    dates = [(today + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(-3, 4)]
    return {"dates": dates, "selected_date": today.strftime("%Y-%m-%d")}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)