$(document).ready(function() {
    const $mealsContainer = $('#meals-container');
    const $loading = $('.loading');
    const $dateButtons = $('#date-buttons');
    let currentDate = '';
    
    function updateVisitCount() {
        $.ajax({
            url: '/api/visits/total',
            method: 'GET',
            success: function(response) {
                $('#visit-counter').text(response.count);
            },
            error: function(error) {
                console.error('Error fetching visit count:', error);
            }
        });
    }
    
    function createStars(rating) {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 >= 0.5;
        let starsHtml = '';
        
        for (let i = 0; i < 5; i++) {
            if (i < fullStars) {
                starsHtml += '<i class="fas fa-star"></i>';
            } else if (i === fullStars && hasHalfStar) {
                starsHtml += '<i class="fas fa-star-half-alt"></i>';
            } else {
                starsHtml += '<i class="far fa-star"></i>';
            }
        }
        
        return `
            <div class="stars">
                ${starsHtml}
            </div>
            <small class="text-muted">(${rating.toFixed(1)}점)</small>
        `;
    }
    
    function createBasicCard(meal, index) {
        return `
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="card h-100" id="school-${meal.school_code}">
                    <div class="card-header bg-white">
                        <h5 class="card-title mb-0">
                            ${index + 1}. ${meal.school_name}
                        </h5>
                    </div>
                    <div class="card-body">
                        <h6 class="card-subtitle mb-2 text-muted">메뉴:</h6>
                        <p class="card-text">${meal.lunch_menu}</p>
                        <div class="review-section">
                            <div class="review-loading text-center">
                                <div class="spinner-border spinner-border-sm text-primary" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                <span class="ms-2">리뷰 생성 중...</span>
                            </div>
                            <div class="review-container"></div>
                        </div>
                    </div>
                    <div class="card-footer bg-white">
                        <div class="text-center review-rating">
                        </div>
                        <div class="reactions-container">
                            <span class="reaction-btn" data-type="like" data-school="${meal.school_code}">
                                <i class="fas fa-thumbs-up"></i>
                            </span>
                            <span class="reaction-count likes-count">0</span>
                            <span class="reactions-divider">|</span>
                            <span class="reaction-btn" data-type="dislike" data-school="${meal.school_code}">
                                <i class="fas fa-thumbs-down"></i>
                            </span>
                            <span class="reaction-count dislikes-count">0</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

   
    
   
    function loadReview(schoolCode, date) {
        const card = $(`#school-${schoolCode}`);
        const reviewContainer = card.find('.review-container');
        const reviewLoading = card.find('.review-loading');
        const reviewRating = card.find('.review-rating');
        
        reviewLoading.show();
        
        $.ajax({
            url: `/api/review/${date}/${schoolCode}`,
            method: 'GET',
            success: function(review) {
                reviewContainer.html(`
                    <h6 class="card-subtitle mb-2 text-muted">리뷰:</h6>
                    <p class="card-text">${review.review}</p>
                `);
                
                reviewRating.html(createStars(review.rating));
                
                // 반응 카운트만 업데이트
                card.find('.likes-count').text(review.reactions.likes);
                card.find('.dislikes-count').text(review.reactions.dislikes);
            },
            error: function(xhr, status, error) {
                reviewContainer.html(`
                    <div class="alert alert-danger" role="alert">
                        리뷰를 불러오는 중 오류가 발생했습니다.
                    </div>
                `);
            },
            complete: function() {
                reviewLoading.hide();
            }
        });
    }
    
    function handleReaction(schoolCode, reactionType, date) {
        const card = $(`#school-${schoolCode}`);
        
        $.ajax({
            url: `/api/reaction/${date}/${schoolCode}/${reactionType}`,
            method: 'POST',
            success: function(response) {
                // 카운트만 업데이트하고 버튼 상태는 변경하지 않음
                card.find('.likes-count').text(response.likes);
                card.find('.dislikes-count').text(response.dislikes);
            },
            error: function(xhr, status, error) {
                alert('반응을 저장하는 중 오류가 발생했습니다.');
            }
        });
    }
    

    function fetchMeals(date) {
        $loading.css('display', 'flex');
        currentDate = date;
        
        $.ajax({
            url: `/api/meals/${date}`,
            method: 'GET',
            success: function(meals) {
                let cardsHtml = '';
                meals.forEach((meal, index) => {
                    cardsHtml += createBasicCard(meal, index);
                });
                
                $mealsContainer
                    .hide()
                    .html(cardsHtml)
                    .fadeIn(400);
                
                meals.forEach(meal => {
                    loadReview(meal.school_code, date);
                });
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
                $mealsContainer.html(`
                    <div class="col-12 text-center">
                        <div class="alert alert-danger" role="alert">
                            데이터를 불러오는 중 오류가 발생했습니다.
                        </div>
                    </div>
                `);
            },
            complete: function() {
                $loading.fadeOut();
            }
        });
    }

    function initializeDateButtons() {
        const today = new Date();
        const dates = [];
        
        for (let i = -3; i <= 3; i++) {
            const date = new Date(today);
            date.setDate(today.getDate() + i);
            dates.push(date.toISOString().split('T')[0]);
        }
        
        dates.forEach(date => {
            const button = $('<button>')
                .addClass('btn btn-outline-primary date-btn')
                .attr('data-date', date)
                .text(new Date(date).toLocaleDateString('ko-KR', {
                    month: 'long',
                    day: 'numeric',
                    weekday: 'short'
                }));
            
            if (date === today.toISOString().split('T')[0]) {
                button.addClass('active');
            }
            
            $dateButtons.append(button);
        });
        
        fetchMeals(today.toISOString().split('T')[0]);
    }

    // 이벤트 핸들러
    $(document).on('click', '.reaction-btn', function() {
        const schoolCode = $(this).data('school');
        const reactionType = $(this).data('type');
        handleReaction(schoolCode, reactionType, currentDate);
    });

    $(document).on('click', '.date-btn', function() {
        $('.date-btn').removeClass('active');
        $(this).addClass('active');
        fetchMeals($(this).data('date'));
    });

    // 초기화
    initializeDateButtons();
    updateVisitCount();
});